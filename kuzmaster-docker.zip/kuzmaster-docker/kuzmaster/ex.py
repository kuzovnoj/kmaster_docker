from django.db import models
from django.conf import settings
from django.utils.text import slugify

class Content(models.Model):
    title = models.CharField(max_length=255)
    slug = models.SlugField(unique=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    metadata = models.JSONField(null=True, blank=True)
    is_published = models.BooleanField(default=True)

    class Meta:
        abstract = True

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.title)
        super().save(*args, **kwargs)


class Article(Content):
    text = models.TextField()
    word_count = models.IntegerField(blank=True)

    def save(self, *args, **kwargs):
        self.word_count = len(self.text.split())
        super().save(*args, **kwargs)

class Video(Content):
    video_url = models.URLField()
    duration = models.DurationField()

class Image(Content):
    image = models.ImageField(upload_to='images/')
    dimensions = models.CharField(max_length=200)


{
    "refresh": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTkzNzczMCwiaWF0IjoxNzYzMzQ1NzMwLCJqdGkiOiJmMDRiMTFhNWIzZmI0NmZiYWRlMWNlOTI3YTQ0MTc2ZiIsInVzZXJfaWQiOiIxIn0.6tx30HG-Ythe1QelZKTG77534J5pQe7BiOVXezSyufQ",
    "access": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNzYzOTUwNTMwLCJpYXQiOjE3NjMzNDU3MzAsImp0aSI6ImI5NDY2NTZiMWE3ZTQyZjM4ODJhZDU1ZTY1NDc0ZWI4IiwidXNlcl9pZCI6IjEifQ.9jMxVk6L7IU0__lzxgoVh9RLWI6sGY2fH57iQ5eFhXQ"
}