from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import Post
from .serializers import PostSerializer


# Напишите здесь ваше решение.
@api_view(['GET'])
def post_list(request):
    list1 = Post.objects.all()
    serializer = PostSerializer(list1, many=True)
    return Response(serializer.data)