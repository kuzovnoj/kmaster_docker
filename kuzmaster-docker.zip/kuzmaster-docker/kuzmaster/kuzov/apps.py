from django.apps import AppConfig


class KuzovConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'kuzov'
